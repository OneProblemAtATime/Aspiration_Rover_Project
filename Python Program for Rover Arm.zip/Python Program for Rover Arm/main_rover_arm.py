#Joshua Merritt
#11/19/2022

#Try to set GPIO. This would fail if run on windows so the try prevents this failure.
try:
    import RPi.GPIO as GPIO, serial
    GPIO.setmode(GPIO.BCM)
    GPIO.setup(21, GPIO.OUT)
    GPIO.setup(20, GPIO.OUT)
    GPIO.setup(26, GPIO.OUT)
    GPIO.setup(5, GPIO.OUT)
    GPIO.setup(6, GPIO.OUT)
    GPIO.setup(24, GPIO.OUT)

    GPIO.output(21, False)
    GPIO.output(20, False)
    GPIO.output(26, False)
    GPIO.output(5, False)
    GPIO.output(6, False)
    GPIO.output(24, False)
    GPIO.setwarnings(False) #Still gives errorwarnings for some reason; however, they don't interfere with the code so it's fine
except:
    pass

#This set of try cases tries to establish a serial connection
#To ACM0 and if that fails, it tries to connect to ACM1
#If this try case isn't here, it may fail at times
#The serial connection floats and changes between ACM0 and ACM1
try:
    ser = serial.Serial('/dev/ttyACM0', 9600, timeout=1)
except:
    pass        
    
try:
    ser = serial.Serial('/dev/ttyACM1', 9600, timeout=1)
except:
    pass

################################################# Subroutine Definitions Starts Here #########################################

#Continuously updating functions
def Picture_display():
    global pic_num
    if pic_num < slide_image_count-1:
        pic_num+=1
    else:
        pic_num=0
    Video.config(image = img[pic_num])
    Video.after(6000, Picture_display)

#Button Commands 
def cmd1():
    try:
        ser.write(b"6\n")
    except:
        pass

def cmd2():
    try:
        ser.write(b"5\n")
    except:
        pass

def cmd3():
    try:
        ser.write(b"4\n")
    except:
        pass

def cmd4():
    try:
        ser.write(b"3\n")
    except:
        pass

def cmd5():
    try:
        ser.write(b"8\n")
    except:
        pass

def cmd6():
    try:
        ser.write(b"7\n")
    except:
        pass

def cmd7():
    try:
        ser.write(b"9\n")
    except:
        pass

def cmd8():
    try:
        ser.write(b"0\n")
    except:
        pass

#Header Bar Subroutine
def Heading_bar(Window_to_head, popup):
    ############## Header Elements Start ################
    #Frames
    head = tk.Frame(Window_to_head, bg="#D3D3D3")
    
    #Labels
    message = tk.Label(head, text='\n Project lead by Dr. Kevin Lewelling. Created by Joshua Merritt with help from Carter Freeze and Tahlia Bergeron.', font=heading_font, bg="#D3D3D3")
    UAFS = tk.Label(head, image=Header_pictures[1], bg="#D3D3D3")

    #Widget Packaging
    head.pack(expand=1, fill=tk.X, anchor=tk.NW)

    message.place(relx=.5, rely=0, anchor=tk.NW)
    UAFS.pack(anchor=tk.W)
    ############## Header Elements End ################


#Subroutine to process images
def Picture_processing(directory, resizeX, resizeY, need_count_flag):
    image_list = os.listdir(directory)
    image_count = len(image_list)
    processed_image_list = []
    for i in range(image_count):
        images = Image.open(directory+image_list[i])
        resize_image = images.resize((resizeX, resizeY))
        processed_image_list.append(ImageTk.PhotoImage(resize_image))
    if need_count_flag == 1:
        return processed_image_list, image_count
    else:
        return processed_image_list  
       
##############################################################################################################################
##############################################################################################################################



##################################################### Main Code Starts Here ##################################################
  
########## Setup Start #########
#Libraries to get time, generate random numbers, build UI, get font data, and open/edit image files
import time as t, random, os, tkinter as tk, tkinter.ttk as ttk, math, sys

##This is an increadibly stupid way of importing pygame.
##With loop suppresses the welcome message.
##This whole with statement if needed can be replaced with the following command: import pygame
with open(os.devnull, 'w') as f:
    # disable stdout
    oldstdout = sys.stdout
    sys.stdout = f

    import pygame

    # enable stdout
    sys.stdout = oldstdout
    
from tkinter.font import Font
from PIL import Image, ImageTk

#Main window
Main_Window = tk.Tk()

##Get the x and y pixel values for relative sizing of the GUI
screen_width = Main_Window.winfo_screenwidth()
screen_height = Main_Window.winfo_screenheight()

##Main_Window.geometry(str(Main_Window.winfo_screenwidth())+'x'+str(Main_Window.winfo_screenheight()))
Main_Window.attributes('-fullscreen', True)

#Image library for handling png/jpg images
Flash_drive_dir = os.path.dirname(os.path.realpath(__file__))
Flash_drive_dir = Flash_drive_dir.replace('\\', '/')
########## Setup End ###########

#Slideshow images (May be called Video below in the Frames/Labels/Widget packaging sections if I didn't fix that before the final version).
pic_num = 0 #This variable tells the program which picture from the img list to display.
page = 0 #This variable is used in the music popup window
main_window_col = "#ADD8E6"

#Slide/Video images used in the main screen
img, slide_image_count = Picture_processing(Flash_drive_dir+'/Images/SlideImages/', 600, 433, 1)#450, 333, 1)

#Header icons and button pictures
Header_pictures = Picture_processing(Flash_drive_dir+'/Images/Header_images/', 32, 32, 0)
Header_pictures.pop(1)
Header_UAFS_logo = Picture_processing(Flash_drive_dir+'/Images/Header_images/', 320, 48, 0)
Header_UAFS_logo.pop(0)
Header_pictures.append(Header_UAFS_logo[0])

#Fonts
button_font = Font(family='Times New Roman', size=30, weight='bold', slant='roman', underline=0)
heading_font = Font(family='Times New Roman', size=10, slant='roman', underline=0)

############## Main Menu Elements Start ################
#Frames
body = tk.Frame(Main_Window, width=screen_width, height=screen_height, bg=main_window_col)
body.pack(fill=tk.BOTH, expand=True, anchor=tk.NW)

Heading_bar(body, Main_Window)#This command draws the header in the main menu window.

Video_Frame = tk.LabelFrame(body, bg='blue', borderwidth=0, highlightthickness=0)
Video_Frame.place(relx=0.75, rely=0.50, anchor=tk.CENTER)

Input_Frame = tk.LabelFrame(body, bg=main_window_col, borderwidth=0, highlightthickness=0)
Input_Frame.place(relx=0.25, rely=0.5, anchor=tk.CENTER)

#Labels
Video = tk.Label(Video_Frame, image=img[pic_num], bg='blue', bd=5, relief=tk.RIDGE)
Video.grid(row=0, column=0)

#Button widgets
Button_1 = tk.Button(Input_Frame, fg='white', font=button_font, text="Front Arm \n Up", bg='blue', command=cmd1, width=10, bd=10, relief=tk.RAISED)
Button_1.grid(row=0, column=0, padx=5, pady=5)

Button_2 = tk.Button(Input_Frame, fg='white', font=button_font, text="Front Arm \n Down", bg='blue', command=cmd2, width=10, bd=10, relief=tk.RAISED)
Button_2.grid(row=0, column=1, padx=5, pady=5)

Button_3 = tk.Button(Input_Frame, fg='white', font=button_font, text="Lower Arm \n Up", bg='blue', command=cmd3, width=10, bd=10, relief=tk.RAISED)
Button_3.grid(row=1, column=0, padx=5, pady=5)

Button_4 = tk.Button(Input_Frame, fg='white', font=button_font, text="Lower Arm \n Down", bg='blue', command=cmd4, width=10, bd=10, relief=tk.RAISED)
Button_4.grid(row=1, column=1, padx=5, pady=5)

Button_5 = tk.Button(Input_Frame, fg='white', font=button_font, text="Sequence 1", bg='blue', command=cmd5, width=10, bd=10, relief=tk.RAISED)
Button_5.grid(row=2, column=0, padx=5, pady=5)

Button_6 = tk.Button(Input_Frame, fg='white', font=button_font, text="Sequence 2", bg='blue', command=cmd6, width=10, bd=10, relief=tk.RAISED)
Button_6.grid(row=2, column=1, padx=5, pady=5)

Button_7 = tk.Button(Input_Frame, fg='white', font=button_font, text="Reset", bg='red', command=cmd7, width=10, bd=10, relief=tk.RAISED)
Button_7.grid(row=3, column=0, padx=5, pady=5)

Button_8 = tk.Button(Input_Frame, fg='white', font=button_font, text="Stop", bg='red', command=cmd7, width=10, bd=10, relief=tk.RAISED)
Button_8.grid(row=3, column=1, padx=5, pady=5)

secret_exit = tk.Button(Main_Window, text="Exit\n \nExit", fg=main_window_col, bg=main_window_col, command=Main_Window.destroy, width=10, bd=10, relief=tk.FLAT)
secret_exit.place(x=0, y=55)
############## Main Menu Elements End ################

#Slide show
Picture_display()

Main_Window.mainloop()



#Extra information

#This will return the width of a frame in units or a child in pixels: print(widget_name.winfo_screenwidth())
#This will return the height of a parent frame in units or a child widget in pixels: print(widget_name.winfo_screenheight())
#This is a combination of the two lines above: print(str(widget_name.winfo_screenwidth())+' x '+str(widget_name.winfo_screenheight())) ----> Output(pixels) = width x height (of widget or frame)

#The following two lines of code will return the widgets within a specified frame (i.e. Main_window = tk.TK())
#children = frame_name.pack_slaves() -- Note change to .grid_slaves() or .place_slaves() if needed
#print(children)

#This command will print out all the variables in the scope that it is called for. (For example if you call this in a subroutine it will print all the local variables defined in that subroutine.)
#print(dir())
